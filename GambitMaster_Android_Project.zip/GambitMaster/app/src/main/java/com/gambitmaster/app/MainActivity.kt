package com.gambitmaster.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

data class Gambit(
    val name: String,
    val eco: String,
    val side: String,
    val difficulty: String,
    val moves: String,
    val idea: String,
    val trap: String,
    val warning: String
)

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 19, 27)
    private val panel = Color.rgb(29, 35, 49)
    private val gold = Color.rgb(230, 184, 92)
    private val white = Color.rgb(244, 245, 248)
    private val muted = Color.rgb(166, 174, 190)

    private val gambits = listOf(
        Gambit("Королевский гамбит", "C30–C39", "За белых", "Средний",
            "1. e4 e5  2. f4",
            "Белые предлагают пешку f ради быстрого развития и атаки на королевском фланге.",
            "Если чёрные жадно удерживают пешку, белые могут получить темпы для развития фигур и давления на центр. Следи за возможностью d4 и быстрым выводом коней и слона.",
            "Гамбит не выигрывает автоматически. После точной защиты чёрные могут принять лишнюю пешку и постепенно уравнять игру."),
        Gambit("Гамбит Эванса", "C51–C52", "За белых", "Средний",
            "1. e4 e5  2. Nf3 Nc6  3. Bc4 Bc5  4. b4",
            "Белые жертвуют пешку b, чтобы выиграть темпы, вскрыть линии и быстро развить фигуры.",
            "Типичная идея: после ...Bxb4 белые играют c3 и d4, нападая на слона и захватывая центр. Важно использовать темпы, а не просто атаковать пешками.",
            "Если белые затянут развитие или начнут преждевременную атаку, материальный перевес чёрных может стать решающим."),
        Gambit("Датский гамбит", "C21", "За белых", "Средний",
            "1. e4 e5  2. d4 exd4  3. c3",
            "Белые предлагают пешку c, а иногда и вторую пешку, ради открытых диагоналей для слонов.",
            "После принятия гамбитной пешки белые стремятся быстро вывести слонов на c4 и b2, создавая давление на f7 и короля.",
            "Не отдавай материал без компенсации: если чёрные спокойно развиваются и возвращают фигуры в защиту, атака может исчезнуть."),
        Gambit("Гамбит Морра", "B21", "За белых", "Средний",
            "1. e4 c5  2. d4 cxd4  3. c3",
            "Белые жертвуют пешку ради быстрого развития, открытых линий и инициативы против сицилианской защиты.",
            "Типичный план: Nf3, Bc4, O-O, Qe2 или Rd1. Давление часто направлено на центральные поля и слабости вокруг короля.",
            "Чёрные могут отказаться от гамбита или вернуть пешку в подходящий момент. Не путай инициативу с гарантированной атакой."),
        Gambit("Гамбит Бенко", "A57–A58", "За чёрных", "Продвинутый",
            "1. d4 Nf6  2. c4 c5  3. d5 b5",
            "Чёрные жертвуют пешку на ферзевом фланге ради долговременного давления по открытым линиям a и b.",
            "После принятия пешки чёрные стремятся поставить ладьи на линии a и b, развить слона на g7 и давить на пешки a2 и b2.",
            "Это позиционный гамбит: не ищи немедленный мат. Компенсация строится на активности фигур и длительном давлении."),
        Gambit("Гамбит Блэкмара — Димера", "D00", "За белых", "Продвинутый",
            "1. d4 d5  2. e4 dxe4  3. Nc3",
            "Белые отдают пешку ради быстрого развития и открытых линий для атаки.",
            "Часто белые продолжают f3, Nxe4 и Bc4, стараясь получить инициативу и давление на короля.",
            "При точной игре чёрные могут удержать лишнюю пешку. Проверяй тактику перед каждой жертвой.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(18), dp(18), dp(18), dp(18))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }

    private fun button(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(gold, 14)
            setOnClickListener { onClick() }
        }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(12), dp(15), dp(12))
        background = rounded(panel, 16)
    }

    private fun showHome() {
        val root = baseLayout()
        root.addView(text("♟  GAMBIT MASTER", 25f, gold, true))
        root.addView(text("MASTER THE TRAPS. CONTROL THE GAME.", 11f, muted, true))
        val hero = card()
        hero.addView(text("Изучай гамбиты.\nНаходи ловушки.", 25f, white, true))
        hero.addView(text("Офлайн-каталог дебютных идей и тактических мотивов.", 14f, muted))
        root.addView(hero, marginParams(top = 22, bottom = 16))
        root.addView(text("БИБЛИОТЕКА ГАМБИТОВ", 13f, gold, true))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gambits.forEachIndexed { index, gambit ->
            val item = card()
            item.addView(text(gambit.name, 18f, white, true))
            item.addView(text("${gambit.side}  •  ${gambit.eco}  •  ${gambit.difficulty}", 12f, muted))
            item.addView(text(gambit.moves, 13f, gold))
            item.addView(button("ОТКРЫТЬ УРОК  →") { showDetail(index) })
            list.addView(item, marginParams(top = 8, bottom = 4))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showDetail(index: Int) {
        val g = gambits[index]
        val root = baseLayout()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(text("←  БИБЛИОТЕКА", 14f, gold, true).apply {
            setOnClickListener { showHome() }
        })
        content.addView(text(g.name, 27f, white, true))
        content.addView(text("${g.side}  •  ${g.eco}  •  ${g.difficulty}", 13f, muted))
        section(content, "СТАРТОВАЯ ЛИНИЯ", g.moves)
        section(content, "ИДЕЯ ГАМБИТА", g.idea)
        section(content, "ТАКТИЧЕСКАЯ ЛОВУШКА / ПЛАН", g.trap)
        section(content, "ВАЖНО ПОМНИТЬ", g.warning)
        content.addView(text("Урок ${index + 1} из ${gambits.size}", 12f, muted))
        content.addView(button("СЛЕДУЮЩИЙ ГАМБИТ  →") {
            showDetail((index + 1) % gambits.size)
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("←  ВСЕ ГАМБИТЫ") { showHome() }, marginParams(top = 10))
        setContentView(root)
    }

    private fun section(parent: LinearLayout, title: String, body: String) {
        val box = card()
        box.addView(text(title, 12f, gold, true))
        box.addView(text(body, 15f, white))
        parent.addView(box, marginParams(top = 12))
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
