# Gambit Master — Android project

Это исходный Android-проект первой версии приложения Gambit Master.

## Что уже работает
- Тёмный интерфейс с золотыми акцентами.
- Офлайн-каталог из 6 гамбитов.
- Страница каждого гамбита: стартовая линия, идея, тактический план и предупреждение.
- Переход между уроками.

## Сборка APK
1. Откройте папку `GambitMaster` в AndroidIDE или Code On The Go как существующий Gradle-проект.
2. Дождитесь синхронизации Gradle. Для сборки нужен интернет на первом запуске, чтобы загрузить Gradle и Android Gradle Plugin.
3. Выберите задачу `:app:assembleDebug` или нажмите Build APK.
4. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Технические параметры
- Kotlin
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
- compileSdk 35, minSdk 23
- Без сторонних UI-библиотек

## Следующий этап
Добавить настоящую интерактивную шахматную доску, проверку легальности ходов, ветвления вариантов и движок Stockfish.
