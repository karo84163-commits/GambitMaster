const fs=require('fs');
const src=['chess.js','data.js'].map(f=>fs.readFileSync(__dirname+'/../www/'+f,'utf8')).join('\n');
const{Chess,O}=new Function(src+';return{Chess,O}')();
const pf=(g,d)=>{if(!d)return 1;let n=0;for(const m of g.legal()){g.make(m);n+=pf(g,d-1);g.undo()}return n};
const t=[[new Chess(),3,8902],[new Chess('r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1'),2,2039],[new Chess('8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1'),3,2812]];
let bad=0;for(const[g,d,e]of t){const n=pf(g,d);console.log('perft',d,n,n==e?'OK':'FAIL '+e);if(n!=e)bad++}
for(const o of O)o.lines.forEach((ln,i)=>{const g=new Chess();for(const s of ln){const san=s.split('|')[0],m=g.legal().find(x=>g.san(x)==san);if(!m){console.log('BAD',o.id,i,san);bad++;break}g.make(m)}});
console.log(bad?'ERRORS':'ALL OK, openings:',O.length);process.exit(bad?1:0);
