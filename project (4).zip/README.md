# Gambit Master
Шахматное приложение (HTML/CSS/JS + Capacitor), работает офлайн.
## Как получить APK с телефона
1. На GitHub создайте репозиторий. Add file → Upload files → загрузите project.zip (не распаковывая).
2. Add file → Create new file → имя `.github/workflows/build-apk.yml`, вставьте содержимое файла build-apk.yml → Commit.
3. Вкладка Actions → Build APK → Run workflow (сборка ~5–8 минут).
4. Главная страница репозитория → Releases → «Gambit Master APK» → скачайте GambitMaster.apk и установите.
## Код
www/chess.js — шахматная логика, www/data.js — дебюты (линии в SAN, `|` — пояснение), www/app.js — интерфейс. `node test/verify.js` проверяет легальность.
