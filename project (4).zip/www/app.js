const pc=p=>`<svg class="pc" viewBox="0 0 45 45"><use href="#${p.toLowerCase()}"/></svg>`,GL={k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟\uFE0E'},$=s=>document.querySelector(s),V=$('#v');
let P={},cur,L,T,sf,sfOk=0,sfH=()=>{},BACK=null;
try{P=JSON.parse(localStorage.gm||'{}')}catch(e){}
const sv=()=>{try{localStorage.gm=JSON.stringify(P)}catch(e){}},strip=s=>s.replace(/[+#]/g,'');
const B={g:new Chess(),flip:0,sel:-1,tg:[],hl:[],mv:[],cb:null};
O.forEach(o=>{o.root={kids:[]};o.lines.forEach((ln,li)=>{let n=o.root;for(const s of ln){const[san,txt]=s.split('|');let k=n.kids.find(x=>x.san==san);if(!k)n.kids.push(k={san,txt,kids:[]});else if(!k.txt&&txt)k.txt=txt;n=k}n.leaf=li})});
const expl=k=>k.txt||(k.san.includes('#')?'Мат!':k.san.includes('+')?'Шах королю.':k.san[0]=='O'?'Рокировка: король в безопасности, ладья в игре.':k.san.includes('x')?'Взятие.':'Развитие фигур и борьба за центр.');
const num=i=>Math.ceil(i/2)+(i%2?'.':'…');
function show(h){V.innerHTML=h;$('#bk').hidden=!BACK;if($('#board'))draw()}
const boardH=()=>'<div id="board"></div><div id="st"></div>';
function draw(){const g=B.g;let h='';for(let k=0;k<64;k++){const i=B.flip?63-k:k,p=g.b[i],c=((i>>3)+(i&7))%2?'d':'l',x=B.hl.length&&(i==B.hl[0]||i==B.hl[1]),t=B.tg.includes(i);
h+=`<div class="sq ${c}${i==B.sel?' s':''}${x?' m':''}${t?' t':''}${p&&t?' x':''}" data-i="${i}">${p?`<span class="${isW(p)?'w':'b'}">${pc(p)}</span>`:''}${k%8==0?`<u class="rk">${8-(i>>3)}</u>`:''}${k>55?`<u class="fl">${'abcdefgh'[i&7]}</u>`:''}</div>`}
$('#board').innerHTML=h;const n=g.legal().length;$('#st').innerHTML=n?`<i class="dot ${g.t}"></i>${g.t=='w'?'Ход белых':'Ход чёрных'}${g.inCheck()?' · шах':''}`:(g.inCheck()?'Мат':'Пат')}
V.addEventListener('click',e=>{const q=e.target.closest('.sq');if(q)tap(+q.dataset.i)});
function tap(i){if(!B.cb)return;const g=B.g,Ls=g.legal();
if(B.sel>=0&&B.tg.includes(i)){const ms=Ls.filter(m=>m.f==B.sel&&m.t==i);B.sel=-1;B.tg=[];if(ms.length>1){B.pm=ms;draw();$('#st').innerHTML='Превращение: '+'QRBN'.split('').map(q=>`<button onclick="promo('${q}')"><span class="${B.g.t=='w'?'w':'b'}">${pc(q)}</span></button>`).join(' ');return}B.cb(ms[0]);return}
const p=g.b[i];if(p&&isW(p)==(g.t=='w')){B.sel=i;B.tg=Ls.filter(m=>m.f==i).map(m=>m.t)}else{B.sel=-1;B.tg=[]}draw()}
function promo(q){const m=B.pm.find(x=>x.p==q);B.pm=null;B.cb(m)}
function doMove(m){B.g.make(m);B.mv.push(m);B.hl=[m.f,m.t]}
function undo(){if(!B.mv.length)return;B.g.undo();B.mv.pop();const l=B.mv[B.mv.length-1];B.hl=l?[l.f,l.t]:[];B.sel=-1;B.tg=[];draw()}
function reset(flip){B.g=new Chess();B.mv=[];B.flip=flip?1:0;B.sel=-1;B.tg=[];B.hl=[];B.cb=null}
const tot=o=>o.lines.length,dn=o=>(P[o.id]||[]).length;
function list(t){BACK=home;nav(t);show(`<h2>${t=='g'?'Гамбиты':'Дебютные ловушки'}</h2><h3>${t=='g'?'Жертва ради инициативы':'Ошибки, которые наказываются'}</h3>`+O.filter(o=>o.t==t).map(o=>`<div class="row" onclick="openO('${o.id}')"><span class="med ${o.s}">${pc(t=='g'?'P':'N')}</span><div><h4>${o.n}</h4><small>${o.d}</small><div class="bar"><u style="width:${dn(o)/tot(o)*100}%"></u></div></div><em>${dn(o)}/${tot(o)}</em></div>`).join(''))}
function openO(id){cur=O.find(o=>o.id==id);BACK=()=>list(cur.t);show(`<h2>${cur.n}</h2><p class="lead">${cur.d}</p><p class="meta"><i class="dot ${cur.s}"></i>Вы играете ${cur.s=='w'?'белыми':'чёрными'} · пройдено ${dn(cur)} из ${tot(cur)}</p><div class="stack"><button class="gold" onclick="learn()">Учить по ходам</button><button onclick="train()">Тренировать</button><button onclick="train('${cur.s=='w'?'b':'w'}')">Тренировать за ${cur.s=='w'?'чёрных':'белых'}</button><button onclick="list('${cur.t}')">‹ К списку</button></div>`)}
const ctlA='<button class="gold" onclick="analyze()">Анализ</button>',boxes='<div id="info" class="box"></div><div id="an" class="box" hidden></div>';
const info=h=>$('#info').innerHTML=h,infoAdd=h=>$('#info').insertAdjacentHTML('beforeend',h);
/* Обучение */
const ln=()=>L.path[L.path.length-1];
function learn(){BACK=()=>openO(cur.id);reset(cur.s=='b');L={path:[cur.root]};show(`<h3>${cur.n} · обучение</h3>${boardH()}<div class="ctl"><button onclick="lback()">◀</button><button onclick="lnext()">▶</button><button onclick="learn()">⟲</button>${ctlA}</div>${boxes}<div class="ctl"><button onclick="openO('${cur.id}')">‹ К разделу</button></div>`);linfo()}
function lplay(k){const m=B.g.mv(k.san);if(!m)return;doMove(m);L.path.push(k);draw();linfo()}
const lnext=()=>{const n=ln();if(n.kids.length)lplay(n.kids[0])},lpick=j=>lplay(ln().kids[j]);
function lback(){if(L.path.length>1){L.path.pop();undo();linfo()}}
function linfo(){const n=ln(),i=L.path.length-1;let h=i?`<p><b>${num(i)} ${n.san}</b> — ${expl(n)}</p>`:'<p>Нажмите ▶, чтобы разобрать линию по ходам. Белые ходят первыми.</p>';
if(n.kids.length>1)h+='<p class="br">Ответвления — выберите продолжение:</p><div class="chips">'+n.kids.map((k,j)=>`<button onclick="lpick(${j})">${k.san}</button>`).join('')+'</div>';
else if(!n.kids.length)h+='<p class="ok">Линия завершена.</p>';$('#info').innerHTML=h;$('#an').hidden=true}
/* Тренировка */
function train(c,rand){BACK=rand?trainer:()=>openO(cur.id);const col=c||cur.s;reset(col=='b');T={node:cur.root,busy:0,col,err:0,rand};
show(`<h3>${rand?'Тренажёр':cur.n+' · тренировка'}</h3>${boardH()}<div class="ctl"><button onclick="hint()">Подсказка</button><button onclick="${rand?'trLine()':`train('${col}')`}">${rand?'Другая линия':'Заново'}</button>${ctlA}</div>${boxes}<div class="ctl"><button onclick="${rand?'trainer()':`openO('${cur.id}')`}">‹ Назад</button></div>`);
B.cb=tmove;const me=col=='w'?'белыми':'чёрными';if(col=='b')setTimeout(()=>{info(`<p>Вы играете ${me}.</p>`);opp()},400);else info(`<p>Вы играете ${me}. Найдите теоретический ход${rand?' и угадайте дебют':''}.</p>`)}
let R={cat:'x',side:'r'};
function trLine(){const f=R.cat=='x'?O:O.filter(o=>o.t==R.cat);cur=f[Math.random()*f.length|0];train(R.side=='r'?'wb'[Math.random()*2|0]:R.side,1)}
function trainer(){BACK=home;const b=(k,v,t)=>`<button class="${R[k]==v?'gold':''}" onclick="R.${k}='${v}';trainer()">${t}</button>`,s=P._s||{w:{n:0,c:0},b:{n:0,c:0}};
show(`<h2>Тренажёр</h2><div class="box"><p>Случайные линии из каталога. Играйте за любую сторону: программа отвечает ходами теории, название дебюта раскрывается в конце.</p></div><h3>Что тренируем</h3><div class="ctl">${b('cat','x','Всё')}${b('cat','g','Гамбиты')}${b('cat','t','Ловушки')}</div><h3>Играть за</h3><div class="ctl">${b('side','w','Белых')}${b('side','b','Чёрных')}${b('side','r','Случайно')}</div><div class="ctl"><button class="gold" onclick="trLine()">Начать</button></div><div class="box"><p>Белые: пройдено ${s.w.n}, без ошибок ${s.w.c}</p><p>Чёрные: пройдено ${s.b.n}, без ошибок ${s.b.c}</p></div>`)}
function fin(){B.cb=null;const s=P._s=P._s||{w:{n:0,c:0},b:{n:0,c:0}};s[T.col].n++;if(!T.err)s[T.col].c++;
if(T.node.leaf!=null&&T.col==cur.s){const a=P[cur.id]=P[cur.id]||[];if(!a.includes(T.node.leaf))a.push(T.node.leaf)}sv();
infoAdd('<p class="ok">✓ Линия пройдена!'+(T.err?` Ошибок: ${T.err}.`:' Без ошибок!')+'</p>');
if(T.rand)infoAdd(`<p>Это был: <b>${cur.n}</b></p><div class="ctl"><button class="gold" onclick="trLine()">Следующая линия ▶</button></div>`)}
function opp(){const n=T.node;if(!n.kids.length)return fin();const k=n.kids[Math.random()*n.kids.length|0],m=B.g.mv(k.san);doMove(m);T.node=k;draw();info(`<p>Соперник: <b>${k.san}</b> — ${expl(k)}</p>`+(k.kids.length?'<p>Ваш ход.</p>':''));if(!k.kids.length)fin()}
function tmove(m){if(T.busy)return;const s=strip(B.g.san(m)),k=T.node.kids.find(x=>strip(x.san)==s);
if(!k){T.err++;info(`<p class="bad">✗ ${s} — не по теории. Попробуйте другой ход или нажмите «Подсказка».</p>`);draw();return}
doMove(m);T.node=k;draw();info(`<p class="ok">✓ <b>${k.san}</b> — ${expl(k)}</p>`);
if(!k.kids.length)fin();else{T.busy=1;setTimeout(()=>{T.busy=0;opp()},600)}}
function hint(){const k=T.node.kids[0];if(!k)return;const m=B.g.mv(k.san);B.sel=m.f;B.tg=[];draw();info(`<p>Подсказка: ходит фигура с поля ${nm(m.f)}.</p>`)}
/* Анализ: Stockfish (если файлы движка есть) или встроенный движок */
try{sf=new Worker('engine/stockfish.js#stockfish.wasm');sf.onmessage=e=>{const l=String(e.data);if(l=='uciok')sfOk=1;sfH(l)};sf.onerror=()=>{sfOk=0};sf.postMessage('uci')}catch(e){}
const sfGo=fen=>new Promise((ok,no)=>{let cp=0,mt=null,d=0;const t=setTimeout(no,12000);
sfH=l=>{if(l.startsWith('info')&&/ score /.test(l)){const a=l.match(/depth (\d+)/),c=l.match(/score (cp|mate) (-?\d+)/);if(a&&c){d=+a[1];if(c[1]=='cp'){cp=+c[2];mt=null}else mt=+c[2]}}
else if(l.startsWith('bestmove')){clearTimeout(t);ok({uci:l.split(' ')[1],cp,mt,d})}};
sf.postMessage('position fen '+fen);sf.postMessage('go depth 12')});
async function analyze(){const out=$('#an'),g=B.g;out.hidden=false;
if(!g.legal().length){out.textContent='Партия окончена.';return}
out.textContent='Анализ…';let m,cp,mt=null,eng;
if(sfOk)try{const r=await sfGo(g.fen()),u=r.uci,sg=g.t=='w'?1:-1;m=g.legal().find(x=>nm(x.f)+nm(x.t)+(x.p?x.p.toLowerCase():'')==u);cp=r.cp*sg;mt=r.mt!=null?r.mt*sg:null;eng='Stockfish, глубина '+r.d}catch(e){m=null}
if(!m){await new Promise(r=>setTimeout(r,40));const r=g.best(3);m=r.m;cp=r.s;eng='встроенный движок, глубина 3';if(Math.abs(cp)>90000){mt=cp>0?1:-1}}
const ev=mt!=null?`мат в пользу ${mt>0?'белых':'чёрных'}`:(cp>0?'+':'')+(cp/100).toFixed(2);
B.hl=[m.f,m.t];draw();out.innerHTML=`<p>Оценка: <b>${ev}</b> (для белых)</p><p>Лучший ход: <b>${g.san(m)}</b> <small>(выделен)</small></p><p><small>Движок: ${eng}</small></p>`}
/* Свободная доска */
function viewAn(){BACK=home;reset(0);B.cb=m=>{doMove(m);$('#an').hidden=true;draw()};show(`<h2>Анализ позиции</h2>${boardH()}<div class="ctl"><button onclick="undo()">◀ Назад</button><button onclick="B.flip^=1;draw()">⇅</button><button onclick="viewAn()">Сброс</button>${ctlA}</div><div id="an" class="box" hidden></div>`)}
function prog(){BACK=home;show('<h2>Прогресс</h2><h3>Пройденные линии</h3>'+O.map(o=>`<div class="row"><div><h4>${o.n}</h4><div class="bar"><u style="width:${dn(o)/tot(o)*100}%"></u></div></div><em>${dn(o)}/${tot(o)}</em></div>`).join('')+`<div class="stack"><button onclick="if(confirm('Сбросить весь прогресс?')){P={};sv();prog()}">Сбросить прогресс</button></div>`)}
function nav(t){document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.t==t))}
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>{const t=b.dataset.t;nav(t);t=='a'?viewAn():t=='r'?trainer():t=='p'?prog():list(t)});
function home(){BACK=null;show(`<h1 class="ttl">Gambit Master</h1><div class="menu">${[['Каталог гамбитов',"list('g')"],['Дебютные ловушки',"list('t')"],['Тренажёр дебютов','trainer()'],['Анализ позиции','viewAn()'],['Мой прогресс','prog()']].map(([t,f])=>`<button class="pill" onclick="${f}">${t}</button>`).join('')}</div>`)}
const AP=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.App;if(AP)AP.addListener('backButton',()=>BACK?BACK():AP.exitApp());
home();
