const START='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const isW=p=>p===p.toUpperCase();
const sq=s=>(8-+s[1])*8+s.charCodeAt(0)-97,nm=i=>String.fromCharCode(97+(i&7))+(8-(i>>3));
const KN=[[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]],KG=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]],RD=KG.slice(0,4),BD=KG.slice(4);
const CR={60:'KQ',4:'kq',63:'K',56:'Q',7:'k',0:'q'},VAL={p:100,n:320,b:330,r:500,q:900,k:0};
class Chess{
constructor(f){this.load(f||START)}
load(f){const[p,t,c,e]=f.split(' ');this.b=[];for(const ch of p){if(ch=='/')continue;if(/\d/.test(ch))for(let i=0;i<+ch;i++)this.b.push(null);else this.b.push(ch)}this.t=t;this.c=c=='-'?'':c;this.e=e&&e!='-'?sq(e):-1;this.h=[]}
fen(){let s='';for(let r=0;r<8;r++){let n=0;for(let c=0;c<8;c++){const p=this.b[r*8+c];if(p){if(n)s+=n;n=0;s+=p}else n++}if(n)s+=n;if(r<7)s+='/'}return`${s} ${this.t} ${this.c||'-'} ${this.e<0?'-':nm(this.e)} 0 1`}
att(i,w){const r=i>>3,c=i&7,g=(y,x)=>y>=0&&y<8&&x>=0&&x<8?this.b[y*8+x]:null,pr=w?r+1:r-1;
for(const d of[-1,1])if(g(pr,c+d)==(w?'P':'p'))return 1;
for(const[x,y]of KN)if(g(r+y,c+x)==(w?'N':'n'))return 1;
for(const[x,y]of KG)if(g(r+y,c+x)==(w?'K':'k'))return 1;
for(const[ds,ps]of[[RD,'R'],[BD,'B']])for(const[x,y]of ds){let yy=r+y,xx=c+x;while(yy>=0&&yy<8&&xx>=0&&xx<8){const q=this.b[yy*8+xx];if(q){if(q==(w?ps:ps.toLowerCase())||q==(w?'Q':'q'))return 1;break}yy+=y;xx+=x}}
return 0}
pseudo(){const m=[],w=this.t=='w';
for(let i=0;i<64;i++){const p=this.b[i];if(!p||isW(p)!=w)continue;const r=i>>3,c=i&7,u=p.toUpperCase(),add=(t,x)=>m.push({f:i,t,...x});
if(u=='P'){const d=w?-1:1,r1=r+d;if(r1<0||r1>7)continue;
const push=t=>{if((t>>3)==(w?0:7))for(const q of'QRBN')add(t,{p:q});else add(t)};
if(!this.b[r1*8+c]){push(r1*8+c);if(r==(w?6:1)&&!this.b[(r1+d)*8+c])add((r1+d)*8+c,{dp:1})}
for(const dc of[-1,1]){const cc=c+dc;if(cc<0||cc>7)continue;const t=r1*8+cc,q=this.b[t];if(q&&isW(q)!=w)push(t);else if(t==this.e)add(t,{ep:1})}}
else if(u=='N'||u=='K'){for(const[x,y]of u=='N'?KN:KG){const cc=c+x,rr=r+y;if(cc<0||cc>7||rr<0||rr>7)continue;const t=rr*8+cc,q=this.b[t];if(!q||isW(q)!=w)add(t)}
if(u=='K'&&i==(w?60:4)){const bs=i,ok=this.c;
if(ok.includes(w?'K':'k')&&!this.b[bs+1]&&!this.b[bs+2]&&this.b[bs+3]==(w?'R':'r')&&![0,1,2].some(k=>this.att(bs+k,!w)))add(bs+2,{cs:1});
if(ok.includes(w?'Q':'q')&&!this.b[bs-1]&&!this.b[bs-2]&&!this.b[bs-3]&&this.b[bs-4]==(w?'R':'r')&&![0,1,2].some(k=>this.att(bs-k,!w)))add(bs-2,{cs:-1})}}
else for(const[x,y]of u=='B'?BD:u=='R'?RD:KG){let yy=r+y,xx=c+x;while(yy>=0&&yy<8&&xx>=0&&xx<8){const t=yy*8+xx,q=this.b[t];if(!q)add(t);else{if(isW(q)!=w)add(t);break}yy+=y;xx+=x}}}
return m}
make(m){this.h.push({b:this.b.slice(),t:this.t,c:this.c,e:this.e});const b=this.b,p=b[m.f],w=this.t=='w';
b[m.t]=m.p?(w?m.p:m.p.toLowerCase()):p;b[m.f]=null;if(m.ep)b[m.t+(w?8:-8)]=null;
if(m.cs){const rk=m.cs>0?m.t+1:m.t-2,to=m.cs>0?m.t-1:m.t+1;b[to]=b[rk];b[rk]=null}
this.e=m.dp?(m.f+m.t)/2:-1;let c=this.c;for(const s of[m.f,m.t])if(CR[s])for(const ch of CR[s])c=c.replace(ch,'');this.c=c;this.t=w?'b':'w'}
undo(){const s=this.h.pop();if(s){this.b=s.b;this.t=s.t;this.c=s.c;this.e=s.e}}
inCheck(){return!!this.att(this.b.indexOf(this.t=='w'?'K':'k'),this.t!='w')}
legal(){const w=this.t=='w',k=w?'K':'k',L=[];for(const m of this.pseudo()){this.make(m);if(!this.att(this.b.indexOf(k),!w))L.push(m);this.undo()}return L}
san(m){const p=this.b[m.f],u=p.toUpperCase(),cap=this.b[m.t]||m.ep;let s;
if(m.cs)s=m.cs>0?'O-O':'O-O-O';
else if(u=='P')s=(cap?nm(m.f)[0]+'x':'')+nm(m.t)+(m.p?'='+m.p:'');
else{const a=this.legal().filter(o=>o.t==m.t&&o.f!=m.f&&this.b[o.f]==p);let d='';
if(a.length)d=!a.some(o=>(o.f&7)==(m.f&7))?nm(m.f)[0]:!a.some(o=>(o.f>>3)==(m.f>>3))?nm(m.f)[1]:nm(m.f);
s=u+d+(cap?'x':'')+nm(m.t)}
this.make(m);const n=this.legal().length,ck=this.inCheck();this.undo();return s+(ck?(n?'+':'#'):'')}
mv(s){s=s.replace(/[+#]/g,'');return this.legal().find(m=>this.san(m).replace(/[+#]/g,'')==s)}
ev(){let s=0;for(let i=0;i<64;i++){const p=this.b[i];if(!p)continue;const u=p.toLowerCase(),r=i>>3,c=i&7;let v=VAL[u];
if(u=='p'||u=='n'||u=='b')v+=(7-Math.abs(2*c-7)-Math.abs(2*r-7)+7)*(u=='p'?2:3)/2;s+=isW(p)?v:-v}return this.t=='w'?s:-s}
ab(d,a,b){const L=this.legal();if(!L.length)return this.inCheck()?-99000-d:0;if(!d)return this.ev();
L.sort((x,y)=>(this.b[y.t]?1:0)-(this.b[x.t]?1:0));
for(const m of L){this.make(m);const s=-this.ab(d-1,-b,-a);this.undo();if(s>=b)return b;if(s>a)a=s}return a}
best(d){let bm=null,a=-1e6;const L=this.legal();L.sort((x,y)=>(this.b[y.t]?1:0)-(this.b[x.t]?1:0));
for(const m of L){this.make(m);const s=-this.ab(d-1,-1e6,-a);this.undo();if(s>a||!bm){a=s;bm=m}}
return{m:bm,s:this.t=='w'?a:-a}}
}
